#!/bin/sh

python3 hw5_parser.py $@
