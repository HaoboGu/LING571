#!/bin/sh

python3 hw1_parse.py $@
