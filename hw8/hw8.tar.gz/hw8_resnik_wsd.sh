#!/bin/sh

python3 hw8_resnik_wsd.py $@