#!/bin/sh

python3 hw6_semantics.py $@
