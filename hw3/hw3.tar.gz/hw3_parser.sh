#!/bin/sh

python3 hw3_parser.py $@
