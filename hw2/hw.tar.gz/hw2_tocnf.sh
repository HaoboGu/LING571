#!/bin/sh

python3 tocnf.py $@
