#!/bin/sh

python3 hw4_improved_to_pcfg.py $@
