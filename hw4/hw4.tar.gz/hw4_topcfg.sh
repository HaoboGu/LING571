#!/bin/sh

python3 hw4_to_pcfg.py $@
