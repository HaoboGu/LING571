#!/bin/sh

python3 hw4_run.py $@
