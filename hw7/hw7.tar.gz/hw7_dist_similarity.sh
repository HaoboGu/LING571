#!/bin/sh

python3 dist_similarity.py $@
