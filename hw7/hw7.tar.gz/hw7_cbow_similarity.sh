#!/bin/sh

python3 cbow_similarity.py $@
