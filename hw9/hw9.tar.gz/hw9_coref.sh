#!/bin/sh

python3 hw9_coref.py $@
